// شروع صفحه

const intro = document.getElementById("intro");
const main = document.getElementById("main");

setTimeout(() => {
    intro.classList.add("hide");
    main.classList.add("show");
}, 3500);



// موزیک

const music = document.getElementById("music");
const play = document.getElementById("play");


play.addEventListener("click", () => {

    if(music.paused){

        music.play();
        play.innerHTML = "⏸ توقف موزیک";

    }else{

        music.pause();
        play.innerHTML = "🎵 پخش موزیک";

    }

});




// متن دلنوشته

const text = `سلام قشنگ‌ترینم  🤍

تولدت مبارک

شاید امسال نتونستم کنارت باشم و این بزرگ‌ترین حسرت امسالمه 🥺

ولی بدون حتی یه لحظه هم از قلبم دور نبودی 🤍

از آخرهای سال ۱۴۰۰ تا امروز هر شب با یادت خوابیدم

توی همه این سال‌ها هیچ شبی نبود که بهت فکر نکنم

تو همیشه توی قلبم بودی و هستی ❤️

خدا بعد از اون همه انتظار دوباره تو رو بهم هدیه داد

و من قدر این هدیه رو با تمام وجودم می‌دونم 🤍

کاش امروز فقط چند دقیقه می‌تونستم کنارت باشم

خنده‌هات...
با هم خندیدن‌هامون...
همه لحظه‌هامون برای من قشنگه 🤍

قول میدم تولدهای بعدی رو کنارت باشم
قول میدم تولدهای بعدی رو حتماً کنارت باشم...

این فقط یه قول نیست

یه آرزوعه که برای رسیدن بهش همه تلاشم رو می‌کنم 🤍

خیلی دوستت دارم آمی...

خیلی بیشتر از چیزی که بشه با کلمه‌ها گفت ❤️

تولدت مبارک عشق قشنگم 🎂🤍
خیلی دوستت دارم حانیه ❤️`;



let index = 0;

function typing(){

    if(index < text.length){

        document.getElementById("letter").innerHTML += text[index];

        index++;

        setTimeout(typing,45);

    }

}


setTimeout(typing,4500);





// ساخت ستاره‌ها

const stars = document.getElementById("stars");


for(let i = 0; i < 80; i++){

    let star = document.createElement("span");

    star.className = "star";

    star.style.left = Math.random()*100 + "%";

    star.style.top = Math.random()*100 + "%";

    star.style.animationDelay = Math.random()*3 + "s";

    stars.appendChild(star);

}





// ساخت قلب‌ها

const hearts = document.getElementById("hearts");


for(let i = 0; i < 25; i++){

    let heart = document.createElement("span");

    heart.className = "heart";

    heart.style.left = Math.random()*100 + "%";

    heart.style.animationDelay = Math.random()*10 + "s";

    heart.style.animationDuration = (6 + Math.random()*8) + "s";

    hearts.appendChild(heart);

}
